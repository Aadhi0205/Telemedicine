import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import axios from "axios";
import { FaHandHoldingMedical } from "react-icons/fa6";
import { SlNote } from "react-icons/sl";
import { GiMedicines } from "react-icons/gi";
import { FaUserDoctor } from "react-icons/fa6";

const PrescriptionPage = () => {
  const patientID = localStorage.getItem("patientID");
  const [prescription, setPrescription] = useState([]);

  const getPatient = async () => {
    try {
      const { data } = await axios.post("/api/v1/patients/getSinglePatient", {
        patientID: patientID,
      });
      if (data?.success) {
        console.log(data?.patient?.prescription);
        setPrescription(data?.patient?.prescription);
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getPatient();
  }, []);
  return (
    <>
      <Header />
      <div className="bg-blue-200 min-h-screen p-4  ">
        <div className="backdrop-blur-sm min-h-screen flex flex-col">
          <h1 className="place-self-center text-6xl font-bold mt-10">
            Prescriptions
          </h1>
          <div className="content p-4 flex  mt-20 overflow-auto h-[80vh] ">
            <div className="flex justify-evenly flex-wrap items-start gap-10">
              {prescription?.map((item) => {
                return (
                  <div className="bg-white shadow-xl rounded-xl p-4 flex flex-col font-bold gap-8 w-[500px] text-lg ">
                    <FaHandHoldingMedical
                      className="place-self-center"
                      size={50}
                    />
                    <div className="flex gap-2">
                      <h1 className="font-bold flex justify-center items-center gap-1">
                        <SlNote size={20} />
                        Note:
                      </h1>{" "}
                      <h1 className="font-semibold">{item.note}</h1>
                    </div>
                    <div className="flex gap-2">
                      <h1 className="font-bold flex justify-center items-center gap-1">
                        <GiMedicines size={25} />
                        Medicine:
                      </h1>{" "}
                      <h1 className="font-semibold">{item.medicine}</h1>
                    </div>
                    <div className="flex gap-2">
                      <h1 className="font-bold flex justify-center items-center gap-1">
                        <FaUserDoctor size={20} />
                        By Doctor:
                      </h1>{" "}
                      <h1 className="font-semibold">{item.docname}</h1>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PrescriptionPage;
