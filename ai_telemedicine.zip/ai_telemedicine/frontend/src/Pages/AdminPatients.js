import React, { useEffect, useState } from "react";
import AdminHeader from "../Components/AdminHeader";
import axios from "axios";
import { FaUser } from "react-icons/fa";

const AdminPatients = () => {
  const [patients, setPatients] = useState([]);

  const getPatients = async () => {
    try {
      const { data } = await axios.get("/api/v1/patients/getAllPatient");
      if (data?.success) {
        console.log(data);
        setPatients(data?.patients);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getPatients();
  }, []);

  return (
    <>
      <AdminHeader />
      <div className="bg-blue-200 min-h-screen p-4">
        <div className="flex mt-14 justify-start flex-wrap gap-10 p-4">
          {patients.map((patient) => {
            return (
              <div className="shadow-xl rounded-xl flex flex-col bg-white p-4 gap-4 ">
                <FaUser className="place-self-center" size={30} />
                <h1 className="font-bold text-lg">Name: {patient.name}</h1>
                <h1 className="font-bold text-lg">Email: {patient.adhaarno}</h1>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default AdminPatients;
