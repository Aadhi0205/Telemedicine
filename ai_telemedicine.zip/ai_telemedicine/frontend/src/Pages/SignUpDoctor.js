import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { MdAddAPhoto } from "react-icons/md";
import axios from "axios";

const SignUpDoctor = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [speciality, setSpeciality] = useState("");
  const [selectedImage, setSelectedImage] = useState();
  const [loading, setLoading] = useState(false);
  const handleSignUP = async () => {
    try {
      if (!name || !email || !password || !speciality) {
        alert("Please fill all fields");
        return;
      }
      const { data } = await axios.post("/api/v1/doctors/createDoctor", {
        name: name,
        email: email,
        password: password,
        speciality: speciality,
        image: selectedImage,
      });
      if (data?.success) {
        alert("SignUp Sucess");
        navigate("/logindoc");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleFileChange = async (e) => {
    setLoading("Uploading....");
    const file = e.target.files[0];

    if (file) {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("upload_preset", "pmcr8gua");
      try {
        const response = await axios.post(
          "https://api.cloudinary.com/v1_1/dgplustqn/image/upload",
          formData
        );

        setSelectedImage(response.data.url);
        setLoading("");
      } catch (error) {
        console.log(error);
      }
    }
  };
  // useEffect(() => {
  //   if (selectedImage) {
  //     setLoading(false);
  //   }
  // }, [selectedImage]);
  return (
    <div className="bg-[url('https://www.ediiie.com/blog/assets/admin/uploads/ai-in-telemedicine.jpg')] min-h-screen min-w-screen bg-cover p-8">
      <div className="flex justify-center items-center h-full">
        <div className=" backdrop-blur-sm bg-white/40  rounded-xl bg-white flex  items-center flex-col p-8">
          <h1 className="font-bold text-[50px] underline underline-offset-2">
            SignUp as Doctor
          </h1>
          <div className="flex flex-col items-center gap-5 mt-10">
            <div className="flex justify-between w-full gap-10">
              {" "}
              <input
                className="w-80 p-3 rounded-xl outline-none border-2 border-black "
                type="text"
                placeholder="Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <input
                className="w-80 p-3 rounded-xl outline-none border-2 border-black"
                type="text"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="flex justify-between w-full gap-10">
              <input
                className="w-80 p-3 rounded-xl outline-none border-2 border-black"
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <input
                className="w-80 p-3 rounded-xl outline-none border-2 border-black"
                type="text"
                placeholder="Speciality for ex (cardiologist)"
                value={speciality}
                onChange={(e) => setSpeciality(e.target.value)}
              />
            </div>

            <label
              className="bg-red-400 hover:scale-105 p-4 rounded-xl justify-center items-center flex gap-2 font-bold cursor-pointer mt-10"
              for="file"
            >
              <MdAddAPhoto size={22} />
              Profile Photo
            </label>

            <input
              className="w-80 p-3 rounded-xl outline-none hidden"
              type="file"
              placeholder="Choose Image"
              id="file"
              accept="image/*"
              onChange={handleFileChange}
            />
            <p>{loading}</p>
            {selectedImage && (
              <div className="font-bold">
                <p className="text-black text-sm">Selected Image:</p>
                <img
                  src={selectedImage}
                  alt="Selected"
                  className="rounded-xl shadow-md h-40 w-48"
                />
              </div>
            )}

            <button
              className="mt-5 p-4 rounded-xl bg-violet-500 font-bold text-lg hover:bg-violet-400 cursor-pointer"
              onClick={handleSignUP}
            >
              SignUp
            </button>
          </div>
          <div className="flex flex-col items-center mt-10 gap-5 text-xl font-bold">
            <h1>
              Already have an account?{" "}
              <Link to="/logindoc" className="underline underline-offset-1">
                Login
              </Link>{" "}
            </h1>
            or
            <h1>
              SignUp as{" "}
              <Link
                to="/signuppatient"
                className="underline underline-offset-1"
              >
                Patient?
              </Link>{" "}
            </h1>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpDoctor;
