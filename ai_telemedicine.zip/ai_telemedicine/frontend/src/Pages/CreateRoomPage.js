import React from "react";
import { useParams } from "react-router-dom";
import { ZegoUIKitPrebuilt } from "@zegocloud/zego-uikit-prebuilt";
const CreateRoomPage = () => {
  const { roomId } = useParams();

  const myMeeting = async (element) => {
    const appID = 501321312;
    const serverSecret = "f9ff3c685b50bce5a4b8580c51b63e5d";
    const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
      appID,
      serverSecret,
      roomId,
      Date.now().toString(),
      "Enter Your Name"
    );

    const zc = ZegoUIKitPrebuilt.create(kitToken);
    zc.joinRoom({
      container: element,
      sharedLinks: [
        {
          name: "Copy Link",
          url: `http://localhost:3000/joinmeet/${roomId}`,
        },
      ],
      scenario: {
        mode: ZegoUIKitPrebuilt.OneONoneCall,
      },
      showScreenSharingButton: false,
    });
  };
  return (
    <>
      <div>
        <div ref={myMeeting} />
      </div>
    </>
  );
};

export default CreateRoomPage;
