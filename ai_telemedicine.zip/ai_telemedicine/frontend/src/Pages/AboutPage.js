import React from "react";
import Header from "../Components/Header";

const AboutPage = () => {
  return (
    <>
      <Header />
      <div className=" min-h-screen bg-blue-200 ">
        <div className="backdrop-blur-sm min-h-screen p-2">
          <div className="p-4 flex flex-col gap-10">
            <h1 className="font-bold place-self-start text-6xl mt-10">
              SwatchArog
            </h1>

            <p className="p-6 font-bold text-xl   ">
              SwatchArog is an innovative healthcare application designed to
              seamlessly connect patients with doctors, revolutionizing the way
              healthcare services are accessed and delivered. At its core,
              SwatchArog empowers patients by providing them with a
              comprehensive platform to interact with healthcare professionals
              from the comfort of their own homes. Through SwatchArog, patients
              can schedule and conduct video consultations with certified
              doctors, facilitating efficient and convenient healthcare access
              regardless of geographical constraints. One of the standout
              features of SwatchArog is its AI-assisted chatbot, which enhances
              the patient experience by providing instant responses to inquiries
              and guiding users through various functionalities of the
              application. This chatbot not only streamlines communication but
              also offers valuable assistance in navigating the platform,
              ensuring that patients make the most out of their interactions
              with healthcare providers. Furthermore, SwatchArog offers robust
              functionality for generating and sharing medical reports. Patients
              can easily generate reports detailing their medical history, test
              results, and other relevant information, which can then be
              securely shared with their designated doctors for further review
              and analysis. This streamlined process facilitates efficient
              collaboration between patients and healthcare professionals,
              ultimately leading to more effective diagnosis and treatment
              planning. For healthcare providers, SwatchArog offers a
              comprehensive solution for managing patient consultations and
              prescriptions. Doctors can seamlessly access patient reports,
              conduct video consultations, and prescribe medications, all within
              the same integrated platform. This not only improves efficiency in
              delivering care but also enhances communication and collaboration
              between doctors and their patients. In summary, SwatchArog is a
              groundbreaking healthcare application that leverages technology to
              redefine the patient-doctor relationship. With its user-friendly
              interface, AI-powered assistance, and comprehensive features for
              virtual consultations and medical report management, SwatchArog
              stands as a beacon of innovation in the realm of telemedicine.
              Whether you're a patient seeking convenient access to healthcare
              services or a doctor looking to streamline your practice,
              SwatchArog offers unparalleled convenience, efficiency, and
              quality of care.
            </p>
            <img
              src="https://imgs.search.brave.com/rhTUYeo22pDnVDUFib8X1604vMUCcULlThrLRPlF1VQ/rs:fit:860:0:0/g:ce/aHR0cHM6Ly90YXRl/ZWRhLmNvbS93cC1j/b250ZW50L3VwbG9h/ZHMvMjAyMy8wOC9U/aGUtSW50ZXJzZWN0/aW9uLW9mLVRlbGVt/ZWRpY2luZS1hbmQt/QUktMTAyNHg1OTgu/anBn"
              className="h-72 w-[800px] place-self-center"
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default AboutPage;
