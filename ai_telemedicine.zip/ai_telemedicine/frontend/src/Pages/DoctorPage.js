import React from "react";
import DoctorHeader from "../Components/DoctorHeader";

const DoctorPage = () => {
  return (
    <>
      <DoctorHeader />
    </>
  );
};

export default DoctorPage;
