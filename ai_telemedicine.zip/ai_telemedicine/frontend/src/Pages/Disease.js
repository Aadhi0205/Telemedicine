import React, { useState, useEffect } from 'react';

function Disease() {
  const [symptoms, setSymptoms] = useState([]);
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [diseasePrediction, setDiseasePrediction] = useState(null);

  // Fetch all symptoms on component mount
  useEffect(() => {
    fetch('http://localhost:8000/allsymptoms')
      .then((response) => response.json())
      .then((data) => setSymptoms(data))
      .catch((error) => console.error('Error fetching symptoms:', error));
  }, []);

  // Handle symptom selection
  const handleSymptomChange = (event) => {
    const symptom = event.target.value;
    if (event.target.checked) {
      setSelectedSymptoms([...selectedSymptoms, symptom]);
    } else {
      setSelectedSymptoms(selectedSymptoms.filter((s) => s !== symptom));
    }
  };

  // Handle form submission to predict disease
  const handleSubmit = (event) => {
    event.preventDefault();

    // Create a URLSearchParams object to encode the form data
    const formData = new URLSearchParams();
    formData.append('symptoms', selectedSymptoms.join(','));

    fetch('http://localhost:8000/predict_disease', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(), // Use URL-encoded form data
    })
      .then((response) => response.json())
      .then((data) => setDiseasePrediction(data))
      .catch((error) => console.error('Error predicting disease:', error));
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-purple-600 to-blue-500 text-white flex items-center justify-center">
      <div className="container mx-auto p-6">
        <div className="bg-white p-8 rounded-lg shadow-lg max-w-xl mx-auto text-gray-800">
          <h1 className="text-4xl font-bold text-center mb-8 text-blue-700">Disease Prediction App</h1>

          <form onSubmit={handleSubmit}>
            <h2 className="text-2xl font-semibold mb-4">Select Your Symptoms</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {symptoms.map((symptom, index) => (
                <div key={index} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`symptom-${index}`}
                    value={symptom}
                    onChange={handleSymptomChange}
                    className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor={`symptom-${index}`} className="ml-3 text-lg text-gray-700">
                    {symptom}
                  </label>
                </div>
              ))}
            </div>

            <button
              type="submit"
              className="mt-8 w-full py-3 px-6 bg-gradient-to-r from-blue-500 to-purple-500 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition duration-300 ease-in-out transform hover:scale-105"
            >
              Predict Disease
            </button>
          </form>

          {diseasePrediction && (
            <div className="mt-8 p-6 bg-green-100 border border-green-300 rounded-lg shadow-lg">
              <h2 className="text-xl font-semibold text-green-800 mb-4">Predicted Disease</h2>
              <p className="text-lg text-green-700">{diseasePrediction.predicted_disease}</p>
            </div>
          )}
        </div>
      </div>
    </div>
    
  );
}

export default Disease;