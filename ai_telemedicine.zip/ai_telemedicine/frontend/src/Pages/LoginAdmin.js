import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const LoginAdmin = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async (req, res) => {
    try {
      if (!email || !password) {
        alert("Please fill all fields");
        return;
      }
      if (email === "admin@gmail.com" && password === "admin12345") {
        navigate("/adminDoc");
      } else {
        alert("Invalid password or email");
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="bg-[url('https://www.ediiie.com/blog/assets/admin/uploads/ai-in-telemedicine.jpg')] h-screen w-screen bg-cover">
      <div className="flex justify-center items-center h-full">
        <div className=" backdrop-blur-sm bg-white/40  w-[450px] rounded-xl bg-white flex  items-center flex-col p-4">
          <h1 className="font-bold text-[50px] underline underline-offset-2">
            Login as Admin
          </h1>
          <div className="flex flex-col items-center gap-5 mt-10">
            <input
              className="w-80 p-3 rounded-xl outline-none"
              type="text"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              className="w-80 p-3 rounded-xl outline-none"
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              className="mt-5 p-4 rounded-xl bg-violet-500 font-bold text-lg hover:bg-violet-400 cursor-pointer"
              onClick={handleLogin}
            >
              LOGIN
            </button>
          </div>
          <div className="flex flex-col items-center mt-10 gap-5 text-xl font-bold">
            <h1>
              Login as{" "}
              <Link to="/" className="underline underline-offset-1 ">
                Patient?
              </Link>{" "}
              or{" "}
              <Link to="/logindoc" className="underline underline-offset-1">
                Doctor?
              </Link>
            </h1>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginAdmin;
