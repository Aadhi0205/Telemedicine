import React, { useEffect, useState } from "react";
import DoctorHeader from "../Components/DoctorHeader";
import axios from "axios";
import { TbPlugConnected } from "react-icons/tb";
import { TbPlugConnectedX } from "react-icons/tb";
import { IoPerson } from "react-icons/io5";
import { useNavigate } from "react-router-dom";
const AppointmentPage = () => {
  const doctorID = localStorage.getItem("doctorID");
  const [appointment, setAppointment] = useState([]);
  const navigate = useNavigate();

  const getDoctor = async () => {
    try {
      const { data } = await axios.post("/api/v1/doctors/singleDoc", {
        doctorID: doctorID,
      });
      if (data?.success) {
        console.log(data?.doctor?.appointments);
        setAppointment(data?.doctor?.appointments);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getDoctor();
  }, []);
  return (
    <>
      <DoctorHeader />
      <div className="min-h-screen bg-blue-200 p-4 flex flex-col">
        <h1 className="place-self-center mt-10 text-6xl font-bold">
          Appointments
        </h1>
        <h1 className="place-self-center mt-10 text-xl font-bold">
          (Total Appointments: {appointment.length})
        </h1>
        <div className="content p-4 flex flex-wrap  gap-20 justify-evenly items-center mt-20">
          {appointment.map((item) => {
            return (
              <div className="bg-white rounded-xl p-8  font-bold text-lg flex flex-col gap-5">
                <IoPerson className="place-self-center" size={80} />
                <p>Patient Name: {item.name}</p>
                <p>Patient Adhaar No: {item.adhaarno}</p>

                <div className="flex justify-center items-center gap-5">
                  <button
                    className="p-4 rounded-xl bg-green-500 cursor-pointer hover:bg-green-400 flex justify-center items-center"
                    onClick={() => navigate("/joinMeet")}
                  >
                    <TbPlugConnected size={30} />
                    Connect
                  </button>
                  <button className="p-4 rounded-xl bg-red-500 cursor-pointer hover:bg-red-400 flex justify-center items-center">
                    <TbPlugConnectedX size={30} />
                    Not Connect
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default AppointmentPage;
