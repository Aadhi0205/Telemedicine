import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import axios from "axios";
import { AiOutlineLoading3Quarters } from "react-icons/ai";
import { MdOutlineConnectWithoutContact } from "react-icons/md";

const AllDoctorsPage = () => {
  const [doctors, setDoctors] = useState([]);
  const [totalDoc, setTotalDocs] = useState();
  const [filteredDoctors, setFilteredDoctors] = useState([]); // New state for filtered doctors
  const [searchTerm, setSearchTerm] = useState(""); // State for search term
  const patientID = localStorage.getItem("patientID");
  const [request, setRequest] = useState(false);

  const getDocs = async () => {
    try {
      const { data } = await axios.get("/api/v1/doctors/allDoctors");
      if (data?.success) {
        setDoctors(data?.doctors);
        setFilteredDoctors(data?.doctors); // Initialize filtered doctors with all doctors
        setTotalDocs(data?.totalDoctors);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleConnect = async (doctorID) => {
    setRequest(true);
    try {
      const { data } = await axios.post(
        "/api/v1/doctors/getDocForAppointment",
        {
          doctorID: doctorID,
          patientID: patientID,
        }
      );
      if (data?.success) {
        setRequest(false);
      }
    } catch (error) {
      console.log(error);
    }
  };

  // Function to handle search
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    const filtered = doctors.filter((doctor) =>
      doctor.speciality.toLowerCase().includes(e.target.value.toLowerCase())
    );
    setFilteredDoctors(filtered);
  };

  useEffect(() => {
    getDocs();
  }, []);

  return (
    <>
      <Header />
      <div className="min-h-screen bg-blue-200 p-4">
        <h1 className="flex justify-center items-center mt-10 font-bold text-5xl">
          All Doctors
        </h1>
        <h1 className="flex justify-center items-center mt-10 font-bold text-xl">
          (Total Doctors: {totalDoc})
        </h1>
        {/* Search input */}
        <div className="flex justify-center mt-6">
          <input
            type="text"
            placeholder="Search by Speciality"
            className="px-4 py-2 rounded-lg border border-gray-400 focus:outline-none focus:border-blue-500"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
        {request ? (
          <div className="w-full flex justify-center items-center animate-spin mt-20">
            <AiOutlineLoading3Quarters size={80} />
          </div>
        ) : (
          <div className="flex mt-14 justify-start flex-wrap gap-10 p-4">
            {filteredDoctors.map((doctor) => {
              return (
                <div
                  key={doctor._id}
                  className="shadow-xl rounded-xl flex flex-col bg-white p-4 gap-4"
                >
                  <img
                    className="w-full rounded-xl h-56"
                    src={doctor.image}
                    alt={doctor.name}
                  />
                  <h1 className="font-bold text-lg">Name: {doctor.name}</h1>
                  <h1 className="font-bold text-lg">Email: {doctor.email}</h1>
                  <h1 className="font-bold text-lg">
                    Speciality: {doctor.speciality}
                  </h1>
                  <button
                    className="bg-violet-400 p-3 rounded-xl font-bold cursor-pointer hover:bg-violet-300 flex justify-center items-center text-xl gap-2"
                    onClick={() => handleConnect(doctor._id)}
                  >
                    <MdOutlineConnectWithoutContact size={30} />
                    Request
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
};

export default AllDoctorsPage;
