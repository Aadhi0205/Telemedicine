import React from "react";
import Header from "../Components/Header";

const PatientMeet = () => {
  const link = localStorage.getItem("link");
  return (
    <>
      <Header />
      <div className="bg-blue-200 min-h-screen flex justify-center items-center">
        <div className="p-4 h-full flex justify-center items-center ">
          {link === null || link === "" ? (
            <h1 className="font-bold text-4xl">No meetings till now</h1>
          ) : (
            <div className="button flex justify-center items-center h-full">
              <a href={link}>
                <button className="bg-violet-500 cursor-pointer p-4 rounded-xl hover:bg-violet-400">
                  Join Meet
                </button>
              </a>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default PatientMeet;
