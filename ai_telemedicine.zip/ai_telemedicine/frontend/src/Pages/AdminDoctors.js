import React, { useEffect, useState } from "react";
import AdminHeader from "../Components/AdminHeader";
import axios from "axios";
const AdminDoctors = () => {
  const [doctors, setDoctors] = useState([]);
  const [totalDoc, settotalDocs] = useState();
  const getDocs = async () => {
    try {
      const { data } = await axios.get("/api/v1/doctors/allDoctors");
      if (data?.success) {
        console.log(data?.doctors);
        setDoctors(data?.doctors);
        settotalDocs(data?.totalDoctors);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getDocs();
  }, []);
  return (
    <>
      <AdminHeader />
      <div className="bg-blue-200 min-h-screen p-4">
        <h1 className="flex justify-center items-center mt-10 font-bold text-xl">
          (Total Doctors: {totalDoc})
        </h1>
        <div className="flex mt-14 justify-start flex-wrap gap-10 p-4">
          {doctors.map((doctor) => {
            return (
              <div className="shadow-xl rounded-xl flex flex-col bg-white p-4 gap-4">
                <img className="w-full rounded-xl h-56" src={doctor.image} />
                <h1 className="font-bold text-lg">Name: {doctor.name}</h1>
                <h1 className="font-bold text-lg">Email: {doctor.email}</h1>
                <h1 className="font-bold text-lg">
                  Speciality: {doctor.speciality}
                </h1>
                <h1 className="font-bold text-lg">
                  Total Appointments: {doctor.appointments.length}
                </h1>
                <h1 className="font-bold text-lg">
                  Total Reports: {doctor.reports.length}
                </h1>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default AdminDoctors;
