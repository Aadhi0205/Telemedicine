import React, { useEffect, useState } from "react";
import axios from "axios";
import DoctorHeader from "../Components/DoctorHeader";
import Modal from "../Components/Modal";
import { CiMedicalClipboard } from "react-icons/ci";

const DoctorReportsPage = () => {
  const [reports, setReports] = useState([]);
  const [patientID, setPatientID] = useState();
  const [showModal, setShowModal] = useState(false);

  const doctorID = localStorage.getItem("doctorID");
  const getDoctor = async () => {
    try {
      const { data } = await axios.post("/api/v1/doctors/singleDoc", {
        doctorID: doctorID,
      });
      if (data?.success) {
        console.log(data);
        setReports(data?.doctor?.reports);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getDoctor();
  }, []);
  return (
    <>
      <DoctorHeader />
      <div className="bg-blue-200 min-h-screen">
        <div className="content p-4 flex justify-start flex-wrap gap-20">
          {reports.map((report) => {
            return (
              <div className="bg-white p-4 flex flex-col gap-4 text-gray-500 font-bold text-lg">
                <img className="h-48" src={report.image} />
                <h1>Patient Name: {report.name}</h1>
                <h1>BP: {report.BP}</h1>
                <h1>Heart Rate : {report.heartrate}</h1>
                <h1>Pulse Rate : {report.pulserate}</h1>
                <h1>Height : {report.height}</h1>
                <h1>Weight: {report.weight}</h1>
                <h1>Sugar: {report.sugar}</h1>
                <h1>Surgeries: {report.surgeries}</h1>

                <button
                  className="p-4 rounded-xl bg-green-500 cursor-pointer hover:bg-green-400 flex justify-center items-center w-full text-black text-lg"
                  onClick={() => {
                    setShowModal(true);
                    setPatientID(report.patientID);
                  }}
                >
                  <CiMedicalClipboard size={30} />
                  Send Prescriptions
                </button>
              </div>
            );
          })}
        </div>
        <Modal
          patientID={patientID}
          isVisible={showModal}
          onClose={() => setShowModal(false)}
        />
      </div>
    </>
  );
};

export default DoctorReportsPage;
