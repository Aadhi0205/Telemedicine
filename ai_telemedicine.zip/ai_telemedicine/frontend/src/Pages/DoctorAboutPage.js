import React from "react";
import DoctorHeader from "../Components/DoctorHeader";

const DoctorAboutPage = () => {
  return (
    <>
      <DoctorHeader />
    </>
  );
};

export default DoctorAboutPage;
