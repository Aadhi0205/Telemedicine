import axios from "axios";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
const LoginPatient = () => {
  const navigate = useNavigate();
  const [adhaarno, setadhaarno] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      if (!adhaarno || !password) {
        alert("Please fill all fields");
        return;
      }

      const { data } = await axios.post("/api/v1/patients/loginPatient", {
        adhaarno: adhaarno,
        password: password,
      });
      if (data?.success) {
        console.log(data);
        localStorage.setItem("patientID", data?.patient._id);
        localStorage.setItem("patientEmail", data?.patient.email);
        navigate("/alldoctors");
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="bg-[url('https://www.ediiie.com/blog/assets/admin/uploads/ai-in-telemedicine.jpg')] h-screen w-screen bg-cover">
      <div className="flex justify-center items-center h-full">
        <div className=" backdrop-blur-sm bg-white/40  w-[450px] rounded-xl bg-white flex  items-center flex-col p-4">
          <h1 className="font-bold text-[50px] underline underline-offset-2">
            Login as Patient
          </h1>
          <div className="flex flex-col items-center gap-5 mt-10">
            <input
              className="w-80 p-3 rounded-xl outline-none"
              type="text"
              placeholder="Adhaar No."
              value={adhaarno}
              onChange={(e) => setadhaarno(e.target.value)}
            />
            <input
              className="w-80 p-3 rounded-xl outline-none"
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              className="mt-5 p-4 rounded-xl bg-violet-500 font-bold text-lg hover:bg-violet-400 cursor-pointer"
              onClick={handleLogin}
            >
              LOGIN
            </button>
          </div>
          <div className="flex flex-col items-center mt-10 gap-5 text-xl font-bold">
            <h1>
              Don't have an account?{" "}
              <Link
                to="/signuppatient"
                className="underline underline-offset-1"
              >
                Register
              </Link>{" "}
            </h1>
            or
            <h1>
              Login as{" "}
              <Link to="/logindoc" className="underline underline-offset-1">
                Doctor?
              </Link>{" "}
              or{" "}
              <Link to="/loginadmin" className="underline underline-offset-1">
                Admin?
              </Link>
            </h1>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPatient;
