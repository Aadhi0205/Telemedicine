import React, { useEffect, useState } from "react";
import Header from "../Components/Header";
import axios from "axios";
import { MdOutlineConnectWithoutContact } from "react-icons/md";
import { IoMdAddCircle } from "react-icons/io";
import { RiAiGenerate } from "react-icons/ri";
import { saveAs } from "file-saver";

const AddReportPage = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [BP, setBP] = useState("");
  const [weight, setweight] = useState("");
  const [height, setheight] = useState("");
  const [sugar, setsugar] = useState("");
  const [surgeries, setsurgeries] = useState("");
  const [heartrate, setheartrate] = useState("");
  const [pulserate, setpulserate] = useState("");
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState("");
  const patientID = localStorage.getItem("patientID");
  const [reports, setReports] = useState([]);
  const [patientName, setPatientName] = useState("");
  const [showDoctorModal, setShowDoctorModal] = useState(false);
  const [doctors, setDoctors] = useState([]);
  const [totalDoc, settotalDocs] = useState();
  const [BP2, setBP2] = useState("");
  const [weight2, setweight2] = useState("");
  const [height2, setheight2] = useState("");
  const [sugar2, setsugar2] = useState("");
  const [surgeries2, setsurgeries2] = useState("");
  const [heartrate2, setheartrate2] = useState("");
  const [pulserate2, setpulserate2] = useState("");
  const [image2, setImage2] = useState("");
  const [reportModal, setReportModal] = useState(false);
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");

  const handleFile = async (e) => {
    const file = e.target.files[0];

    if (file) {
      setLoading("Uploading....");
      const formData = new FormData();
      formData.append("file", file);
      formData.append("upload_preset", "pmcr8gua");

      try {
        const response = await axios.post(
          "https://api.cloudinary.com/v1_1/dgplustqn/image/upload",
          formData
        );
        setLoading("Uploaded");
        setImage(response.data.url);

        // You can also store the image URL in your state or send it to your server.
      } catch (error) {
        console.error(
          "Error uploading image to Cloudinary:",
          error.response.data
        );
      }
    }
  };

  const getPatient = async () => {
    try {
      const { data } = await axios.post("/api/v1/patients/getSinglePatient", {
        patientID: patientID,
      });
      if (data?.success) {
        setPatientName(data?.patient.name);
        setReports(data?.patient?.reports);
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getPatient();
  }, []);

  const handleSaveReport = async () => {
    try {
      const { data } = await axios.post("/api/v1/patients/createreport", {
        patientID: patientID,
        BP: BP,
        weight: weight,
        height: height,
        heartrate: heartrate,
        pulserate: pulserate,
        sugar: sugar,
        surgeries: surgeries,
        image: image,
      });

      if (data?.success) {
        console.log(data);
        setBP("");
        setImage("");
        setheartrate("");
        setpulserate("");
        setsugar("");
        setsurgeries("");
        setheight("");
        setweight("");
        setLoading("");
        setModalOpen(false);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const getDocs = async () => {
    try {
      const { data } = await axios.get("/api/v1/doctors/allDoctors");
      if (data?.success) {
        setDoctors(data?.doctors);
        settotalDocs(data?.totalDoctors);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleSend = async (id) => {
    try {
      const { data } = await axios.post("/api/v1/doctors/createreport", {
        name: patientName,
        doctorID: id,
        BP: BP2,
        weight: weight2,
        height: height2,
        heartrate: heartrate2,
        pulserate: pulserate2,
        sugar: sugar2,
        surgeries: surgeries2,
        image: image2,
        patientID: patientID,
      });
      if (data.success) {
        alert("Report send successfully");
        console.log(data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleGenerateReport = async () => {
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    canvas.width = 800; // Adjust canvas size as needed
    canvas.height = 1200; // Adjust canvas size as needed

    // Background and section dividers
    context.fillStyle = "#f5f5f5"; // Light gray background
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.fillStyle = "#ddd"; // Divider color

    // Title section
    context.font = "30px Arial bold";
    context.fillStyle = "#333"; // Darker text color
    context.fillText("Patient Health Report", canvas.width / 2 - 150, 50); // Center title

    // Demographics section
    context.font = "20px Arial bold";
    context.fillText("Patient Information", 30, 120);
    context.font = "16px Arial";
    context.fillText("Name:", 50, 150);
    context.fillText(`${patientName}`, 120, 150); // Replace with actual name
    context.fillText("Age:", 50, 180);
    context.fillText(`${age}`, 120, 180); // Replace with actual age
    context.fillText("Gender:", 50, 210);
    context.fillText(`${gender}`, 120, 210); // Replace with actual gender

    // Vitals section
    context.strokeRect(10, 250, canvas.width - 20, 300); // Section divider
    context.font = "20px Arial bold";
    context.fillText("Vitals", 30, 300);
    context.font = "16px Arial";
    context.fillText("Blood Pressure:", 50, 330);
    context.fillText(`${BP}`, 180, 330); // Replace with actual value
    context.fillText("Pulse Rate:", 50, 360);
    context.fillText(`${pulserate}`, 180, 360);
    context.fillText("Surgeries:", 50, 390);
    context.fillText(`${surgeries}`, 180, 390);
    context.fillText("Sugar level:", 50, 420);
    context.fillText(`${sugar}`, 180, 420);
    context.fillText("Weight:", 50, 450);
    context.fillText(`${weight}`, 180, 450);
    context.fillText("Height:", 50, 480);
    context.fillText(`${height}`, 180, 480);

    const dataURL = canvas.toDataURL("image/png");

    const link = document.createElement("a");
    link.href = dataURL;
    link.download = `${patientName}_health_report.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setBP("");

    setheartrate("");
    setpulserate("");
    setsugar("");
    setsurgeries("");
    setheight("");
    setweight("");
    setAge("");
    setGender("");

    setReportModal(false);
  };

  return (
    <>
      <Header />
      <div className="bg-blue-200 min-h-screen">
        <div className="content p-4 flex justify-center items-center gap-10">
          <button
            className="bg-violet-500 p-4 rounded-xl font-bold text-lg hover:scale-105 cursor-pointer hover:bg-violet-400 flex justify-center items-center gap-2"
            onClick={() => setModalOpen(true)}
          >
            <IoMdAddCircle size={30} />
            Add Report
          </button>
          <p className="font-bold text-3xl">or</p>
          <button
            className="bg-violet-500 p-4 rounded-xl font-bold text-lg hover:scale-105 cursor-pointer hover:bg-violet-400 flex justify-center items-center gap-2"
            onClick={() => setReportModal(true)}
          >
            <RiAiGenerate size={30} />
            Generate Report
          </button>
        </div>
        <div className="p-4 flex justify-start items-center mt-20 gap-5 flex-wrap">
          {reports.map((report) => {
            return (
              <div className="bg-white p-4 shadow-xl rounded-xl flex flex-col gap-4 font-bold text-gray-500 w-[300px]">
                <img
                  className="w-[290px] place-self-center rounded-xl"
                  src={report.image}
                />
                <h1>Name: {patientName}</h1>
                <h1>BP: {report.BP}</h1>
                <h1>Heart Rate: {report.heartrate}</h1>
                <h1>Pulse Rate: {report.pulserate}</h1>
                <h1>Sugar: {report.sugar}</h1>
                <h1>Height: {report.height}</h1>
                <h1>Weight: {report.weight}</h1>
                <h1>Surgeries: {report.surgeries}</h1>
                <button
                  className="p-4 rounded-xl bg-violet-500 hover:bg-violet-400 cursor-pointer font-semibold text-black"
                  onClick={() => {
                    setBP2(report.BP);
                    setheartrate2(report.heartrate);
                    setpulserate2(report.pulserate);
                    setsugar2(report.sugar);
                    setheight2(report.height);
                    setweight2(report.weight);
                    setsurgeries2(report.surgeries);
                    setImage2(report.image);
                    setShowDoctorModal(true);
                    getDocs();
                  }}
                >
                  Send Report
                </button>
              </div>
            );
          })}
        </div>
        <div className="flex justify-center items-center p-4">
          {showDoctorModal && (
            <div className="fixed inset-0  bg-black bg-opacity-25 backdrop-blur-sm flex justify-center items-center p-4">
              <div className="w-[500px] p-4 overflow-auto">
                <div className="bg-white p-2 rounded-lg  flex flex-col justify-start items-center gap-6 overflow-auto">
                  <h1 className="font-bold text-xl">Doctors</h1>

                  <div className="flex flex-col justify-start gap-10  overflow-auto p-4">
                    <div className="flex flex-col h-[500px] justify-start items-center gap-10 overflow-auto">
                      {doctors.map((doctor) => {
                        return (
                          <div className="shadow-xl w-[300px] rounded-xl flex flex-col bg-white p-4 gap-4">
                            <img
                              className="w-full rounded-xl h-56"
                              src={doctor.image}
                            />
                            <h1 className="font-bold text-lg">
                              Name: {doctor.name}
                            </h1>
                            <h1 className="font-bold text-lg">
                              Email: {doctor.email}
                            </h1>
                            <h1 className="font-bold text-lg">
                              Speciality: {doctor.speciality}
                            </h1>
                            <button
                              className="bg-violet-400 p-3 rounded-xl font-bold cursor-pointer hover:bg-violet-300 flex justify-center items-center text-xl gap-2"
                              onClick={() => handleSend(doctor._id)}
                            >
                              <MdOutlineConnectWithoutContact size={30} />
                              Send
                            </button>
                          </div>
                        );
                      })}
                    </div>
                    <button
                      className="bg-red-400 p-4 rounded-xl hover:bg-red-300 w-60 place-self-center  font-bold text-lg"
                      onClick={() => {
                        setShowDoctorModal(false);
                        setLoading("");
                      }}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="flex justify-center items-center p-4">
          {modalOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-25 backdrop-blur-sm flex justify-center items-center p-4">
              <div className="w-[500px]">
                <div className="bg-white p-2 rounded-lg  flex flex-col justify-center items-center gap-6">
                  <h1 className="font-bold text-xl">Report</h1>

                  <div className="flex flex-col justify-center gap-10 w-[50vw]">
                    <div className="flex justify-center flex-col gap-5 items-center mt-5">
                      <div className="flex justify-evenly gap-10">
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="BP"
                          value={BP}
                          onChange={(e) => setBP(e.target.value)}
                        />
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Sugar"
                          value={sugar}
                          onChange={(e) => setsugar(e.target.value)}
                        />
                      </div>
                      <div className="flex justify-evenly gap-10">
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Heart Rate"
                          value={heartrate}
                          onChange={(e) => setheartrate(e.target.value)}
                        />
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Pulse Rate"
                          value={pulserate}
                          onChange={(e) => setpulserate(e.target.value)}
                        />
                      </div>
                      <div className="flex justify-evenly gap-10">
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Surgeries"
                          value={surgeries}
                          onChange={(e) => setsurgeries(e.target.value)}
                        />
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Height"
                          value={height}
                          onChange={(e) => setheight(e.target.value)}
                        />
                      </div>

                      <input
                        className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                        cols={50}
                        placeholder="Weight"
                        value={weight}
                        onChange={(e) => setweight(e.target.value)}
                      />
                      <label
                        className="mt-5 bg-violet-500 p-4 rounded-xl font-semibold text-lg cursor-pointer hover:bg-violet-400 hover:scale-105"
                        htmlFor="file"
                      >
                        Select Report
                      </label>
                      {loading}

                      <input
                        id="file"
                        className="hidden"
                        type="file"
                        onChange={handleFile}
                      />
                    </div>
                    <div className="flex justify-center items-center gap-10">
                      {" "}
                      <button
                        className="bg-green-400 p-4 rounded-xl hover:bg-green-300  font-bold text-lg"
                        onClick={handleSaveReport}
                      >
                        Save
                      </button>
                      <button
                        className="bg-red-400 p-4 rounded-xl hover:bg-red-300  font-bold text-lg"
                        onClick={() => {
                          setBP("");
                          setImage("");
                          setheartrate("");
                          setpulserate("");
                          setsugar("");
                          setsurgeries("");
                          setheight("");
                          setweight("");
                          setLoading("");
                          setModalOpen(false);
                          setLoading("");
                        }}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="flex justify-center items-center p-4">
          {reportModal && (
            <div className="fixed inset-0 bg-black bg-opacity-25 backdrop-blur-sm flex justify-center items-center p-4">
              <div className="w-[500px]">
                <div className="bg-white p-2 rounded-lg  flex flex-col justify-center items-center gap-6">
                  <h1 className="font-bold text-xl">Report Generation</h1>

                  <div className="flex flex-col justify-center gap-10 w-[50vw]">
                    <div className="flex justify-center flex-col gap-5 items-center mt-5">
                      <div className="flex justify-evenly gap-10">
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="BP"
                          value={BP}
                          onChange={(e) => setBP(e.target.value)}
                        />
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Sugar"
                          value={sugar}
                          onChange={(e) => setsugar(e.target.value)}
                        />
                      </div>
                      <div className="flex justify-evenly gap-10">
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Heart Rate"
                          value={heartrate}
                          onChange={(e) => setheartrate(e.target.value)}
                        />
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Pulse Rate"
                          value={pulserate}
                          onChange={(e) => setpulserate(e.target.value)}
                        />
                      </div>
                      <div className="flex justify-evenly gap-10">
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Surgeries"
                          value={surgeries}
                          onChange={(e) => setsurgeries(e.target.value)}
                        />
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Height"
                          value={height}
                          onChange={(e) => setheight(e.target.value)}
                        />
                      </div>
                      <div className="flex justify-evenly gap-10">
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Weight"
                          value={weight}
                          onChange={(e) => setweight(e.target.value)}
                        />
                        <input
                          className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                          cols={50}
                          placeholder="Age"
                          value={age}
                          onChange={(e) => setAge(e.target.value)}
                        />
                      </div>

                      <input
                        className="bg-slate-200 outline-none rounded-xl shadow-xl p-4"
                        cols={50}
                        placeholder="Gender"
                        value={gender}
                        onChange={(e) => setGender(e.target.value)}
                      />
                    </div>
                    <div className="flex justify-center items-center gap-10">
                      {" "}
                      <button
                        className="bg-green-400 p-4 rounded-xl hover:bg-green-300  font-bold text-lg"
                        onClick={handleGenerateReport}
                      >
                        Generate
                      </button>
                      <button
                        className="bg-red-400 p-4 rounded-xl hover:bg-red-300  font-bold text-lg"
                        onClick={() => {
                          setBP("");

                          setheartrate("");
                          setpulserate("");
                          setsugar("");
                          setsurgeries("");
                          setheight("");
                          setweight("");
                          setAge("");
                          setGender("");
                          setReportModal(false);
                        }}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default AddReportPage;
