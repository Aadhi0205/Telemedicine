import React from "react";
import { FaUserCircle } from "react-icons/fa";
const Cards = ({ cardData }) => {
  return (
    <>
      {cardData?.map((item) => {
        return (
          <div className="shadow-xl p-4 rounded-xl w-fit font-bold text-xl flex flex-col gap-5 border-2 border-black">
            {item.image ? (
              <img className="h-56 rounded-xl w-full" src={item.image} />
            ) : (
              <FaUserCircle className="place-self-center" size={100} />
            )}
            <h1>Name: {item.name}</h1>
            {item.email ? (
              <h1>Email: {item.email}</h1>
            ) : (
              <h1>Adhaar No: {item.adhaarno}</h1>
            )}
            {item.speciality ? <h1>Speciality: {item.speciality}</h1> : null}
          </div>
        );
      })}
    </>
  );
};

export default Cards;
