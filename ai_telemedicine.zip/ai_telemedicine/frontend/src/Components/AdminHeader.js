import React from "react";
import { FaUserDoctor } from "react-icons/fa6";
import { TbReport } from "react-icons/tb";
import { Link } from "react-router-dom";

const AdminHeader = () => {
  return (
    <>
      <div className="header h-20 bg-black text-white flex justify-between items-center px-10">
        <div className="font-bold text-4xl">AI CareNet</div>
        <div className="flex justify-center items-center gap-16 font-bold text-2xl">
          <Link
            className="hover:scale-105 hover:underline hover:underline-offset-4 cursor-pointer flex justify-center items-center gap-1"
            to="/admindoc"
          >
            <FaUserDoctor />
            Doctors
          </Link>
          <Link
            className="hover:scale-105 hover:underline hover:underline-offset-4 cursor-pointer flex justify-center items-center gap-1"
            to="/adminpatient"
          >
            <TbReport />
            Patients
          </Link>{" "}
          <Link
            className="hover:scale-105 hover:underline hover:underline-offset-4 cursor-pointer flex justify-center items-center gap-1"
            to="/"
          >
            <TbReport />
            Logout
          </Link>
        </div>
      </div>
    </>
  );
};

export default AdminHeader;
